export const requestTableHeader = [
    "ID",
    "Priority",
    "Subject",
    "Requester Name",
    "Group",
    "Status",
    "Comment",
    "Last Updated",
    "Owner",
    "Due By Date",
    "Created",
    "Technician",
    "Linked Request"
]

export const pageTitle = "Dashboard"